package com.springmvc.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.springmvc.model.Employee;

@Repository
public class EmployeeDAO {
	
	@PersistenceContext private EntityManager entityManager;
	
	

	public List<Employee> getAllEmployees() {
		
		System.out.println("TEST MVC1");
		
		String jpql = "SELECT e FROM Employee e";
        TypedQuery<Employee> query = entityManager.createQuery(jpql, Employee.class);
        
           return query.getResultList();
        
			}
}
