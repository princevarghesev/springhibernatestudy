package com.springmvc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="employee")
public class Employee {

	@Id
    @Column(name="empid")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	public int empid;
	
	@Column(name="empname")
	public String empname;
	
	@Column(name="age")
	public int age;
	
	@Column(name="location")
	public String location;
	
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Employee(int empid, String empname, int age, String location) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.age = age;
		this.location = location;
	}
	
   public Employee() {
	   
   }
}
