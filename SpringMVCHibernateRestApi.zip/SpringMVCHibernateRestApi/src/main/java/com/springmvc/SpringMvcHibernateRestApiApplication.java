package com.springmvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcHibernateRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcHibernateRestApiApplication.class, args);
	}

}
