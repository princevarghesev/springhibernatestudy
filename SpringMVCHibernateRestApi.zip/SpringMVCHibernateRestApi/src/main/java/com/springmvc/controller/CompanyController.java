package com.springmvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springmvc.model.Employee;
import com.springmvc.service.EmployeeService;

@RestController
@RequestMapping("/mvchibernate")
public class CompanyController {
	
	@Autowired
	EmployeeService employeeService;
	
	 @GetMapping(value = "/getAllEmployees")
	    public List<Employee> getEmployeesList() {
		 
		 @SuppressWarnings("unchecked")
		List<Employee> listOfEmployees = employeeService.getAllEmployees();
	        return listOfEmployees;
	    }

}
