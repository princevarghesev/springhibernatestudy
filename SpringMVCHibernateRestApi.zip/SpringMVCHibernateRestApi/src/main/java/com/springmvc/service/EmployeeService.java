package com.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springmvc.repository.EmployeeDAO;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeDAO employeeDaoObj;
	
	public List getAllEmployees() {	
		return employeeDaoObj.getAllEmployees();
	}
}
